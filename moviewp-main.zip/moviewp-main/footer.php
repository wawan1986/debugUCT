<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @author: Film Update
 * @author URI: https://movies.bulukumba,shop
 * @copyright: (c) 2022 Film Update. All rights reserved
 * ----------------------------------------------------
 * @since 3.8.7
 * 20 May 2022
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
	</main><!-- #main -->
    <footer id="colophon" class="site-footer" role="contentinfo">
        <div class="site-info">
            <p>&copy; <?php echo date( 'Y' ); ?> LK21-Official. All rights reserved.</p>
        </div><!-- .site-info -->
    </footer><!-- #colophon -->
</div><!-- #site-container -->
<?php wp_footer(); ?>
	
</body>
</html>
