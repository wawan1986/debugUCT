<?php
/**
 * Template part for displaying page content in index.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @author: Muhammad Yusran
 * @author URI: https://bulukumba.shop
 * @copyright: (c) 2022 Film Update. All rights reserved
 * ----------------------------------------------------
 * @since 3.8.7
 * 20 May 2022
 */

/* Exit if accessed directly */
if (!defined('ABSPATH')) {
    exit;
}

echo '<section id="content" class="inner-container">';
echo Notice();
echo '<div class="item-container">';


// Movies Loop
$args_movies = array(
    'orderby' => 'post_date',
    'order' => 'DESC',
    'post_type' => 'post',
    'post_status' => 'publish',
    'posts_per_page' => get_option('posts_per_page'),
    'category_name' => 'movies' // Kategori "movies"
);

$loop_movies = new WP_Query($args_movies);

if ($loop_movies->have_posts()) :
    

    // Judul Film Terbaru
    echo '<h2 class="judul-section atas">Film Terbaru</h2>';

    while ($loop_movies->have_posts()) : $loop_movies->the_post();

        get_template_part('template-parts/content/content', 'loop');

    endwhile;

    // Reset query untuk Movies Loop
    wp_reset_postdata();

else :
    echo '<p>';
    esc_html_e('Sorry, no movies posts matched your criteria.', 'moviewp');
    echo '</p>';

endif;

// TV Series Loop
$args_tv_series = array(
    'orderby' => 'post_date',
    'order' => 'DESC',
    'post_type' => 'post',
    'post_status' => 'publish',
    'posts_per_page' => get_option('posts_per_page'),
    'category_name' => 'tv-series' // Kategori "tv-series"
);

$loop_tv_series = new WP_Query($args_tv_series);

if ($loop_tv_series->have_posts()) :

    // Judul Drama Terbaru
    echo '<h2 class="judul-section bawah">Drama Terbaru</h2>';

    while ($loop_tv_series->have_posts()) : $loop_tv_series->the_post();

        get_template_part('template-parts/content/content', 'loop');

    endwhile;

    // Reset query untuk TV Series Loop
    wp_reset_postdata();

else :
    echo '<p>';
    esc_html_e('Sorry, no TV series posts matched your criteria.', 'moviewp');
    echo '</p>';

endif;

echo '</div>'; // Penutup div.item-container
echo '</section>'; // Penutup section#content
?>
