<?php
/*
* ----------------------------------------------------
* @author: Muhammad Yusran
* @author URI: https://bulukumba.shop
* @copyright: (c) 2022 Film Update. All rights reserved
* ----------------------------------------------------
* @since 3.8.7
* 20 May 2022
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

//The licenses for this product are lifetime, this type of license allows you to obtain free updates and extra activations, access to support is permanent.

define	('MOVIEWP_LICENSE', $MOVIEWP_LICENSE); 